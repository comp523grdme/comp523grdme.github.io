/* This file handles JS specific to the upload page */
'use strict';

(function () {
	$('#cancel').on('click', function () {
		window.close();
	});
})();